import asyncio, pathlib
from playwright.async_api import async_playwright

root=pathlib.Path('/mnt/data/zekais-clone')
html=(root/'index.html').read_text(encoding='utf-8')
css=(root/'style.css').read_text(encoding='utf-8')
js=(root/'app.js').read_text(encoding='utf-8')
html=html.replace('<link rel="stylesheet" href="style.css">', f'<style>{css}</style>')
html=html.replace('<script src="app.js"></script>', f'<script>{js}</script>')

async def main():
  async with async_playwright() as p:
    browser=await p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--disable-gpu'])
    for name,w,h in [('desktop',1440,900),('mobile',390,844),('tablet',768,1024),('wide',1920,1080)]:
      page=await browser.new_page(viewport={'width':w,'height':h}, device_scale_factor=1)
      await page.set_content(html, wait_until='load')
      await page.screenshot(path=str(root/f'{name}-inline.png'), full_page=True)
      metrics=await page.evaluate('''() => ({scrollHeight:document.documentElement.scrollHeight, bodyWidth:document.body.getBoundingClientRect().width, overflow:document.documentElement.scrollWidth-document.documentElement.clientWidth, details:[...document.querySelectorAll('details')].length, open:[...document.querySelectorAll('details[open]')].length, bots:document.querySelectorAll('.bot-row:not(.head)').length, features:document.querySelectorAll('.feature-card').length, float:!!document.querySelector('.report-float')})''')
      print(name,metrics)
    await browser.close()

asyncio.run(main())
