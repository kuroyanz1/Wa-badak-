# ZEKAIS Clone v7 — Audit & Validation

Tanggal: 26 September 2026

## A. Yang diverifikasi terhadap halaman ZEKAIS live

Acuan live yang dibaca hari ini menunjukkan homepage memiliki hero, daftar bot, 6 fitur, quickstart, pricing, 12 FAQ, footer, serta floating Grup Laporan. Clone v7 mempertahankan struktur tersebut.

### Struktur
- 5 bagian utama: hero + Features + Quickstart + Pricing + FAQ
- 6 kartu fitur
- 12 item FAQ
- 48 baris bot snapshot
- footer + floating Grup Laporan

### Data snapshot
- Hero terminal: `live · 1.370 bot`
- Ringkasan: `1.371 bot online · 1.135 public · 236 self · 31 siap masuk grup`
- Daftar 48 bot mengikuti daftar yang tampil pada crawl live yang dipakai untuk iterasi ini.

Catatan: angka/list bot di situs asli berubah-ubah, sehingga clone statis tidak bisa dijamin sama selamanya tanpa backend live.

## B. Perbedaan fungsional yang ditemukan dan diperbaiki di v7

1. `Mulai Gratis` sekarang menuju halaman login live.
2. `Cara Jadibot` sekarang menuju halaman `carajadibot` live.
3. Tombol pricing `Mulai Sekarang — Gratis` sekarang menuju login live.
4. Link footer `cara jadibot` sekarang menuju `carajadibot`.
5. Link footer `dashboard` sekarang menuju `/dashboard`.

## C. Pengujian otomatis v7

PASS:
- HTML parsing
- JavaScript syntax (`node --check`)
- CSS brace balance
- 6 feature cards
- 12 FAQ items
- 48 bot rows
- floating Grup Laporan hadir
- 3 responsive viewports: 1440×900, 768×1024, 390×844
- tidak ada horizontal overflow pada ketiga viewport
- menu toggle JS bekerja
- semua 12 FAQ dapat dibuka
- screenshot render lokal berhasil dibuat untuk ketiga viewport

## D. Yang belum bisa dinyatakan identik 100%

Pixel-by-pixel diff belum dapat dijalankan karena raster screenshot halaman live ZEKAIS tidak tersedia dari renderer yang sama di lingkungan ini. Karena itu tidak ada persentase kemiripan yang dibuat-buat.

Detail renderer yang masih bisa menyebabkan perbedaan meski HTML/CSS terlihat sama: font file aktual, anti-aliasing, device scale factor, versi browser/engine, scrollbar, dan data live.

## Kesimpulan

v7 adalah versi yang lebih teruji dan memperbaiki mismatch route yang terukur. **Status 100% pixel-identical: belum terbukti.**
