# ZEKAIS live snapshot used for v13

Checked from the live homepage on 26 September 2026.

- Hero count: 1.362 bot
- Online summary: 1.362 bot online · 1.127 public · 235 self · 30 siap masuk grup
- Bot table: 48 rows, priorities 1470 through 1421
- Features: 6
- FAQ: 12
- Quickstart prompt: `>./quickstart.sh`
- Pricing text and footer matched to live extraction
- Floating Grup Laporan present

This is a content snapshot, not a claim that live production data will stay unchanged.
