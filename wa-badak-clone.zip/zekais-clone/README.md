# WA Badak homepage recreation — v4

Recreation mandiri berbasis HTML/CSS/JS untuk pengujian visual tampilan homepage WA Badak.

## Isi
- `index.html` — struktur homepage
- `style.css` — layout, warna, typography, responsive mobile
- `app.js` — tabel bot snapshot + menu mobile + smooth-scroll

## Yang diperbarui di v4
- Menambahkan link `⊕ Tambah bot ke grup` pada terminal hero.
- Menambahkan bubble floating `💬 Grup Laporan` di bawah kanan/layar mobile.
- Menyamakan isi seluruh 12 FAQ dengan konten homepage live yang diperiksa pada 26 September 2026.
- Tetap memakai data bot sebagai snapshot deterministik agar render visual tidak berubah-ubah.

## Menjalankan
Buka `index.html` di browser.

## Catatan penting
Clone ini ditujukan sebagai recreation visual/struktur, bukan salinan backend atau data live WA Badak. Jumlah bot pada situs asli bersifat dinamis sehingga snapshot clone dapat berbeda dari angka live saat dibuka.

`100% pixel-identical` belum diklaim karena pembuktian itu membutuhkan dua screenshot dari viewport, browser, font, aset, dan kondisi render yang sama lalu dibandingkan pixel-by-pixel.
