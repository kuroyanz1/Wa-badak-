# WA Badak Branding

Clone ini telah direbrand dari ZEKAIS menjadi **WA Badak**.

Yang diubah pada halaman utama:
- Nama/brand menjadi WA Badak
- Title dan meta description
- Terminal username/path menjadi wabadak
- Referensi bot menjadi WA Badak
- Teks pricing dan FAQ yang menyebut brand
- Perintah follow menjadi `.followwabadak`
- Footer menjadi WA Badak
- Identitas operasional footer menjadi `wabadak.id`

Struktur HTML/CSS/JS utama dipertahankan agar perubahan branding tidak mengubah layout secara sengaja.
