import asyncio, pathlib
from playwright.async_api import async_playwright

ROOT=pathlib.Path('/mnt/data/zekais-clone')
html=(ROOT/'index.html').read_text(encoding='utf-8')
css=(ROOT/'style.css').read_text(encoding='utf-8')
js=(ROOT/'app.js').read_text(encoding='utf-8')
html=html.replace('<link rel="stylesheet" href="style.css">', f'<style>{css}</style>')
html=html.replace('<script src="app.js"></script>', f'<script>{js}</script>')

async def main():
    viewports={'desktop':(1440,900),'tablet':(768,1024),'mobile':(390,844)}
    async with async_playwright() as p:
        browser=await p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--font-render-hinting=none','--no-sandbox'])
        for name,(w,h) in viewports.items():
            page=await browser.new_page(viewport={'width':w,'height':h}, device_scale_factor=1)
            await page.set_content(html, wait_until='load')
            await page.wait_for_timeout(500)
            # functional smoke checks
            sw=await page.evaluate('document.documentElement.scrollWidth')
            cw=await page.evaluate('document.documentElement.clientWidth')
            feats=await page.locator('.feature-card').count()
            faq=await page.locator('details').count()
            bots=await page.locator('.bot-row:not(.head)').count()
            float_ok=await page.locator('.report-float').count()
            menu_state='n/a'
            if name=='mobile':
                await page.locator('#menuBtn').click()
                menu_state=await page.locator('#nav').evaluate('(el)=>el.classList.contains("open")')
                await page.locator('#menuBtn').click()
            # verify every FAQ can open
            faq_results=[]
            for i in range(faq):
                await page.locator('details').nth(i).click()
                faq_results.append(await page.locator('details').nth(i).evaluate('(el)=>el.open'))
            await page.screenshot(path=str(ROOT/f'{name}-v8.png'), full_page=True)
            print(name, {'viewport':f'{w}x{h}','scrollWidth':sw,'clientWidth':cw,'features':feats,'faq':faq,'bots':bots,'float':float_ok,'menu_open_after_click':menu_state,'all_faq_opened':all(faq_results)})
        await browser.close()

asyncio.run(main())
