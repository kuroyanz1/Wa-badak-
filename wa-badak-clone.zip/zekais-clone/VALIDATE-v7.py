import asyncio, pathlib, re
from bs4 import BeautifulSoup
from playwright.async_api import async_playwright

ROOT=pathlib.Path('/mnt/data/zekais-clone')
raw=(ROOT/'index.html').read_text(encoding='utf-8')
css=(ROOT/'style.css').read_text(encoding='utf-8')
js=(ROOT/'app.js').read_text(encoding='utf-8')
soup=BeautifulSoup(raw,'html.parser')
checks=[]
checks.append(('html_parse', bool(soup.html and soup.body and soup.head)))
checks.append(('features_6', len(soup.select('.feature-card'))==6))
checks.append(('faq_12', len(soup.select('details'))==12))
checks.append(('bot_rows_js_48', len(re.findall(r"[\"\'](?:628|601)\*+",js))==48))
checks.append(('report_float', bool(soup.select_one('.report-float'))))
checks.append(('login_routes', raw.count('https://zekais.id/login')>=3))
checks.append(('carajadibot_routes', raw.count('https://zekais.id/carajadibot')>=2))
checks.append(('dashboard_route', 'https://zekais.id/dashboard' in raw))
checks.append(('css_balanced', css.count('{')==css.count('}')))
assert all(v for _,v in checks), [k for k,v in checks if not v]

async def run(viewport):
  name,w,h=viewport
  async with async_playwright() as p:
    browser=await p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--disable-gpu'])
    page=await browser.new_page(viewport={'width':w,'height':h}, device_scale_factor=1)
    inline=raw.replace('<link rel="stylesheet" href="style.css">','<style>'+css+'</style>').replace('<script src="app.js"></script>','<script>'+js+'</script>')
    await page.set_content(inline, wait_until='load')
    m=await page.evaluate('''() => ({
      sw:document.documentElement.scrollWidth,cw:document.documentElement.clientWidth,
      features:document.querySelectorAll('.feature-card').length,
      faq:document.querySelectorAll('details').length,
      bots:document.querySelectorAll('.bot-row:not(.head)').length,
      float:!!document.querySelector('.report-float'),
      open:document.querySelectorAll('details[open]').length
    })''')
    assert m['sw']==m['cw'], (name,m)
    assert (m['features'],m['faq'],m['bots'],m['float'])==(6,12,48,True)
    # Exercise mobile menu logic regardless of viewport.
    await page.evaluate("document.querySelector('#menuBtn').click()")
    assert await page.locator('#nav').evaluate("e=>e.classList.contains('open')")
    await page.evaluate("document.querySelector('#menuBtn').click()")
    assert not await page.locator('#nav').evaluate("e=>e.classList.contains('open')")
    # Exercise every FAQ using in-page native click, avoiding 12 round trips.
    res=await page.evaluate('''() => {
      const ds=[...document.querySelectorAll('details')];
      const out=[];
      for (const d of ds) { if (d.open) d.open=false; d.querySelector('summary').click(); out.push(d.open); d.open=false; }
      return out;
    }''')
    assert all(res) and len(res)==12
    await page.screenshot(path=str(ROOT/f'{name}-v7.png'), full_page=True)
    await browser.close()
    return m

async def main():
  for vp in [('desktop',1440,900),('mobile',390,844),('tablet',768,1024)]:
    print(vp[0], await run(vp))
  print('PASS:', ', '.join(k for k,_ in checks), '+ 3 responsive renders + menu + all 12 FAQ interactions')

asyncio.run(main())
