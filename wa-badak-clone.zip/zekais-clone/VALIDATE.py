from pathlib import Path
from bs4 import BeautifulSoup
import re, subprocess, sys

ROOT = Path(__file__).resolve().parent
html = ROOT/'index.html'
js = ROOT/'app.js'
css = ROOT/'style.css'

s = BeautifulSoup(html.read_text(encoding='utf-8'), 'html.parser')
checks=[]
def ck(name, ok, detail=''):
    checks.append((name, bool(ok), detail))

ck('HTML parses', True)
ck('Viewport meta', bool(s.select_one('meta[name="viewport"]')))
ck('CSS linked', bool(s.find('link', href='style.css')))
ck('JS linked', bool(s.find('script', src='app.js')))
ck('Hero copy', s.select_one('.hero h1') and 'Management' in s.select_one('.hero h1').get_text(' ', strip=True))
ck('Feature cards = 6', len(s.select('.feature-card')) == 6, str(len(s.select('.feature-card'))))
ck('Quickstart heading', s.select_one('#quickstart h2') and '4 langkah, 90 detik' in s.select_one('#quickstart h2').get_text(' ',strip=True))
ck('Pricing block', s.select_one('#pricing .live-pricing') is not None)
ck('FAQ entries = 12', len(s.select('#faq details')) == 12, str(len(s.select('#faq details'))))
ck('Footer present', s.select_one('footer.footer') is not None)
ck('Floating Grup Laporan', s.select_one('.report-float') is not None)
ck('Footer VIP link', s.find('a', string=lambda x: x and 'keuntungan vip' in x).get('href') == 'https://zekais.id/keuntungan' if s.find('a', string=lambda x: x and 'keuntungan vip' in x) else False)

src = js.read_text(encoding='utf-8')
rows = re.search(r'const bots=\[(.*?)\];', src, re.S)
row_count = src.count("['628") + src.count("['601")
ck('Bot dataset rows = 48', row_count == 48, str(row_count))
ck('Current live total in hero = 1.370', 'live · 1.370 bot' in html.read_text())
ck('Current live online summary = 1.371', '1.371 bot online' in html.read_text())
ck('Current live footer count = 1.371', 'menampilkan 48 bot terbaru dari 1.371' in html.read_text())
ck('Responsive breakpoint <=980', '@media(max-width:980px)' in css.read_text())
ck('Responsive breakpoint <=700', '@media(max-width:700px)' in css.read_text())

try:
    r=subprocess.run(['node','--check',str(js)],capture_output=True,text=True,timeout=10)
    ck('JavaScript syntax', r.returncode==0, r.stderr.strip())
except Exception as e:
    ck('JavaScript syntax', False, str(e))

bad=[c for c in checks if not c[1]]
print(f'PASS {len(checks)-len(bad)}/{len(checks)}')
for n,ok,d in checks:
    print(('PASS' if ok else 'FAIL')+': '+n+(f' — {d}' if d else ''))
if bad:
    sys.exit(1)
