from pathlib import Path
import re, subprocess
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).parent
html=(ROOT/'index.html').read_text(encoding='utf-8')
js=(ROOT/'app.js').read_text(encoding='utf-8')
css=(ROOT/'style.css').read_text(encoding='utf-8')

assert '<!doctype html>' in html.lower()
assert len(re.findall(r'<article class="feature-card">', html)) == 6
assert len(re.findall(r'<details(?: open)?>', html)) == 12
assert '48 bot terbaru' in html
assert 'Grup Laporan' in html
for route in ('https://zekais.id/login','https://zekais.id/carajadibot','https://zekais.id/dashboard'):
    assert route in html
assert js.count('],[') + 1 == 48
assert css.count('{') == css.count('}')
subprocess.run(['node','--check',str(ROOT/'app.js')],check=True)

inline = html.replace('<link rel="stylesheet" href="style.css">', f'<style>{css}</style>')
inline = inline.replace('<script src="app.js"></script>', f'<script>{js}</script>')

viewports=[('desktop',1440,900),('tablet',768,1024),('mobile',390,844),('wide',1920,1080)]
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--font-render-hinting=none','--no-sandbox'])
    for name,w,h in viewports:
        page=browser.new_page(viewport={'width':w,'height':h}, device_scale_factor=1)
        page.set_content(inline, wait_until='load')
        page.wait_for_timeout(350)
        metrics=page.evaluate('''() => ({
          scrollWidth: document.documentElement.scrollWidth,
          clientWidth: document.documentElement.clientWidth,
          bots: document.querySelectorAll('.bot-row:not(.head)').length,
          features: document.querySelectorAll('.feature-card').length,
          faq: document.querySelectorAll('details').length,
          float: !!document.querySelector('.report-float')
        })''')
        assert metrics['scrollWidth'] <= metrics['clientWidth'], (name,metrics)
        assert metrics['bots']==48 and metrics['features']==6 and metrics['faq']==12 and metrics['float']
        if w<=700:
            page.locator('#menuBtn').click()
            assert page.locator('#nav.open').count()==1
            page.locator('#menuBtn').click()
            assert page.locator('#nav.open').count()==0
        for i in range(12):
            d=page.locator('details').nth(i)
            if not d.evaluate('el=>el.open'):
                d.locator('summary').click()
            assert d.evaluate('el=>el.open')
        for i in range(12):
            d=page.locator('details').nth(i)
            assert d.evaluate('el=>el.open')
        page.screenshot(path=str(ROOT/f'{name}-v13.png'), full_page=True)
        print(name, metrics)
        page.close()
    browser.close()
print('VALIDATE-v13 PASS')
