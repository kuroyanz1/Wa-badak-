#!/usr/bin/env python3
import argparse
from pathlib import Path
from PIL import Image
import numpy as np

p=argparse.ArgumentParser(description='Pixel diff two screenshots.')
p.add_argument('reference')
p.add_argument('candidate')
p.add_argument('--json', action='store_true')
a=p.parse_args()

ref=Image.open(a.reference).convert('RGBA')
cand=Image.open(a.candidate).convert('RGBA')
if ref.size != cand.size:
    raise SystemExit(f'size mismatch: reference={ref.size}, candidate={cand.size}')

A=np.asarray(ref,dtype=np.int16)
B=np.asarray(cand,dtype=np.int16)
d=np.abs(A-B)
mask=np.any(d != 0, axis=2)
pixels=int(mask.size)
diff=int(mask.sum())
mae=float(d.mean())
maxerr=int(d.max())
sim=100.0*(pixels-diff)/pixels
out={
    'width': ref.width,
    'height': ref.height,
    'pixels': pixels,
    'different_pixels': diff,
    'different_pixel_percent': 100.0*diff/pixels,
    'identical_pixel_percent': sim,
    'mean_absolute_channel_error': mae,
    'max_channel_error': maxerr,
}
if a.json:
    import json
    print(json.dumps(out, indent=2))
else:
    print(f"size: {ref.width}x{ref.height}")
    print(f"different pixels: {diff}/{pixels} ({out['different_pixel_percent']:.6f}%)")
    print(f"identical pixels: {sim:.6f}%")
    print(f"mean absolute channel error: {mae:.6f}")
    print(f"max channel error: {maxerr}")
