# WA Badak Clone v14

Standalone HTML/CSS/JS recreation of the WA Badak homepage structure.

## Validation

`VALIDATE-v13.py` checks HTML/JS/CSS structure, bot count, feature count, FAQ count, routes, and screenshot rendering at desktop/tablet/mobile/wide viewports.

`pixel_diff.py REFERENCE.png CANDIDATE.png` computes exact raster similarity when a real reference screenshot is available from the same renderer conditions.

The build is not labeled 100% pixel-identical without that direct raster-vs-raster comparison.
