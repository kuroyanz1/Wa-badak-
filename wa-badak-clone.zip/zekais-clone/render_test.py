import asyncio, os
from playwright.async_api import async_playwright

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--font-render-hinting=none'])
        for name,w,h in [('desktop',1440,900),('mobile',390,844)]:
            page = await browser.new_page(viewport={'width':w,'height':h}, device_scale_factor=1)
            await page.goto('file:///mnt/data/zekais-clone/index.html', wait_until='networkidle')
            await page.screenshot(path=f'/mnt/data/zekais-clone/{name}-v6.png', full_page=True)
            print(name, await page.evaluate('document.documentElement.scrollHeight'), await page.locator('details').count(), await page.locator('.bot-row:not(.head)').count())
        await browser.close()

asyncio.run(main())
